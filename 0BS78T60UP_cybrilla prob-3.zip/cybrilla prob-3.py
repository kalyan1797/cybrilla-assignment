a = input().lower()
n = ""
for i in a:
    n = i + n
if n == a:
    print("true")
else:
    print("false")